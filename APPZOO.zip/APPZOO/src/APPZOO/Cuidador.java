package APPZOO;

public class Cuidador {
    private String nombre;
    private int edad;
    private char sexo; // Cambiado a String
    private String operacion;
    private String animalACargo;

    // Constructor
    public Cuidador(String nombre, int edad, char sexo, String operacion, String animalACargo2) {
        this.nombre = nombre;
        this.edad = edad;
        this.sexo = sexo;
        this.operacion = operacion;
        this.animalACargo = animalACargo2;
    }

    // Métodos getter y setter
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public char getSexo() { // Cambiado a String
        return sexo;
    }

    public void setSexo(char sexo) { // Cambiado a String
        this.sexo = sexo;
    }

    public String getOperacion() {
        return operacion;
    }

    public void setOperacion(String operacion) {
        this.operacion = operacion;
    }

    public String getAnimalACargo() {
        return animalACargo;
    }

    public void setAnimalACargo(String animalACargo) {
        this.animalACargo = animalACargo;
    }

    // Método toString para imprimir los detalles del cuidador
    @Override
    public String toString() {
        return "Cuidador{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", sexo='" + sexo + '\'' +
                ", operacion='" + operacion + '\'' +
                ", animalACargo=" + animalACargo +
                '}';
    }
}

