package APPZOO;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ZooManager zooManager = new ZooManager(); // Clase para gestionar el zoológico
        boolean ingresoDatoRealizado = false;
        
        while (true) {
            System.out.println("Bienvenido a APPZOO");
            System.out.println("1. Ingresar dato");
            System.out.println("2. Buscar dato");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer de entrada
            
            switch (opcion) {
                case 1:
                    ingresarDato(zooManager, scanner);
                    ingresoDatoRealizado = true;
                    break;
                case 2:
                    if (!ingresoDatoRealizado) {
                        System.out.println("Debe ingresar un dato antes de buscar.");
                        break;
                    }
                    buscarDato(zooManager, scanner);
                    break;
                case 3:
                    System.out.println("Gracias por usar APPZOO. ¡Hasta luego!");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
            }
        }
    }

    private static void ingresarDato(ZooManager zooManager, Scanner scanner) {
        System.out.println("¿Qué dato desea ingresar? (1. Animal  2. Cuidador  3. Operacion)");
        int opcion = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer de entrada
        
        switch (opcion) {
            case 1:
                ingresarAnimal(zooManager, scanner);
                break;
            case 2:
                ingresarCuidador(zooManager, scanner);
                break;
            case 3:
                ingresarOperacion(zooManager, scanner);
                break;
            default:
                System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
        }
    }

    private static void buscarDato(ZooManager zooManager, Scanner scanner) {
        System.out.println("¿Qué quiere buscar? (1. Animal  2. Cuidador  3. Operacion)");
        int opcion = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer de entrada
        
        switch (opcion) {
            case 1:
                // Lógica para buscar y mostrar datos de animales
                break;
            case 2:
                // Lógica para buscar y mostrar datos de cuidadores
                break;
            case 3:
                // Lógica para buscar y mostrar datos de operaciones
                break;
            default:
                System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
        }
    }

    private static void ingresarAnimal(ZooManager zooManager, Scanner scanner) {
        System.out.println("Ingresar datos del animal:");
        System.out.print("Especie: ");
        String especie = scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer de entrada
        System.out.print("Sexo: ");
        String sexo = scanner.nextLine();
        System.out.print("Lugar: ");
        String lugar = scanner.nextLine();
        
        Animal animal = new Animal(especie, nombre, edad, sexo, lugar);
        zooManager.agregarAnimal(animal);
        System.out.println("Animal ingresado correctamente.");
    }

    private static void ingresarCuidador(ZooManager zooManager, Scanner scanner) {
        System.out.println("Ingresar datos del cuidador:");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer de entrada
        System.out.print("Sexo: ");
        char sexo = scanner.nextLine().charAt(0);
        System.out.print("Operacion: ");
        String operacion = scanner.nextLine();
        System.out.print("Animal a cargo: ");
        String animalACargo = scanner.nextLine();
        
        Cuidador cuidador = new Cuidador(nombre, edad, sexo, operacion, animalACargo);
        zooManager.agregarCuidador(cuidador);
        System.out.println("Cuidador ingresado correctamente.");
    }

    private static void ingresarOperacion(ZooManager zooManager, Scanner scanner) {
        System.out.println("Ingresar datos de la operacion:");
        System.out.print("Tipo de operacion (alimentacion/salud): ");
        String tipo = scanner.nextLine();
        if (!tipo.equalsIgnoreCase("alimentacion") && !tipo.equalsIgnoreCase("salud")) {
            System.out.println("Tipo de operacion no válido. Por favor, seleccione 'alimentacion' o 'salud'.");
            return;
        }
        System.out.print("Cuidador a cargo: ");
        String cuidadorACargo = scanner.nextLine();
        
        Operacion operacion = new Operacion(tipo, cuidadorACargo);
        zooManager.agregarOperacion(operacion);
        System.out.println("Operacion ingresada correctamente.");
    }
}


