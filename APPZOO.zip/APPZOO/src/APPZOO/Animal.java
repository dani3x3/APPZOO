package APPZOO;

public class Animal {
    private String especie;
    private String nombre;
    private int edad;
    private String sexo;
    private String lugar;

    // Constructor
    public Animal(String especie, String nombre, int edad, String sexo, String lugar) {
        this.especie = especie;
        this.nombre = nombre;
        this.edad = edad;
        this.sexo = sexo;
        this.lugar = lugar;
    }

    // Métodos getter y setter
    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    // Método toString para imprimir los detalles del animal
    @Override
    public String toString() {
        return "Animal{" +
                "especie='" + especie + '\'' +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", sexo=" + sexo +
                ", lugar='" + lugar + '\'' +
                '}';
    }
}

