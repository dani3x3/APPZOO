package APPZOO;

public class Operacion {
    private String tipoOperacion;

    // Constructor
    public Operacion(String tipoOperacion, String cuidadorACargo) {
        this.tipoOperacion = tipoOperacion;
    }

    // Métodos getter y setter
    public String getTipoOperacion() {
        return tipoOperacion;
    }

    public void setTipoOperacion(String tipoOperacion) {
        this.tipoOperacion = tipoOperacion;
    }

    // Método toString para imprimir el tipo de operación
    @Override
    public String toString() {
        return "Operacion{" +
                "tipoOperacion='" + tipoOperacion + '\'' +
                '}';
    }
}
